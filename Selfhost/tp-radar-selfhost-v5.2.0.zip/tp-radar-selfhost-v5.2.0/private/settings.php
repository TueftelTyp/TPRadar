<?php
/** Public configuration rules. Server-only. Do not put secrets in this file. */
declare(strict_types=1);
function tpDefaults(): array { return [
 'first_price_review'=>false,
 'deviation_review'=>true,
 'ean_required'=>false,
 'warning_percent'=>10,
 'hold_percent'=>30,
 'confirmations_required'=>2,
 'valid_days'=>30,
 'pending_expire_days'=>30,
 'max_price_reports_day'=>20,
 'max_new_products_day'=>5,
 'max_new_stores_day'=>5,
 'new_products_require_approval'=>false,
 'new_stores_require_approval'=>false,
 'ranking_default'=>'sheet',
 'home_search_default'=>true,
 'show_expired'=>false,
 'show_pending'=>true,
 'prefer_store_filter'=>true,
 'auto_cleanup'=>false,
 'cleanup_days'=>90,
 'cleanup_rejected'=>true,
 'cleanup_inactive'=>true,
 'audit_retention_days'=>365,
]; }
function tpValidateSettings(array $input): array {
 $defaults=tpDefaults();
 if(array_keys($input)!==array_keys($defaults) && (count($input)!==count($defaults) || array_diff(array_keys($input),array_keys($defaults)) || array_diff(array_keys($defaults),array_keys($input)))) throw new InvalidArgumentException('Unbekannte oder fehlende Einstellungswerte.');
 $bools=['first_price_review','deviation_review','ean_required','new_products_require_approval','new_stores_require_approval','home_search_default','show_expired','show_pending','prefer_store_filter','auto_cleanup','cleanup_rejected','cleanup_inactive'];
 foreach($bools as $key) if(!is_bool($input[$key])) throw new InvalidArgumentException("$key muss wahr oder falsch sein.");
 $bounds=['warning_percent'=>[1,99],'hold_percent'=>[2,300],'confirmations_required'=>[1,5],
 'valid_days'=>[1,365],'pending_expire_days'=>[1,365],
 'max_price_reports_day'=>[1,200],'max_new_products_day'=>[1,50],'max_new_stores_day'=>[1,50],
 'cleanup_days'=>[7,3650],'audit_retention_days'=>[30,3650]];
 foreach($bounds as $key=>$b) if(!is_int($input[$key])||$input[$key]<$b[0]||$input[$key]>$b[1]) throw new InvalidArgumentException("$key muss zwischen {$b[0]} und {$b[1]} liegen.");
 if($input['hold_percent']<=$input['warning_percent']) throw new InvalidArgumentException('Die Halteschwelle muss über der Warnschwelle liegen.');
 if(!in_array($input['ranking_default'],['sheet','layer_sheet','roll'],true))throw new InvalidArgumentException('Ungültiges Standardranking.');
 return $input;
}
function tpSettings(PDO $db): array {
 $row=$db->query('SELECT settings_json FROM app_settings WHERE id=1')->fetchColumn();
 if($row===false) {
  // Preserve any existing V5.1 moderation.php decisions until an admin saves new settings.
  $defaults=tpDefaults();$file=__DIR__.'/moderation.php';
  if(is_file($file)){
   $old=require $file;
   if(is_array($old)){
    $defaults['deviation_review']=(bool)($old['enabled']??true);
    $defaults['warning_percent']=(int)round(100*(float)($old['warning_threshold']??0.1));
    $defaults['hold_percent']=(int)round(100*(float)($old['hold_threshold']??0.3));
    $defaults['confirmations_required']=(int)($old['confirmations_required']??2);
   }
  }
  return tpValidateSettings($defaults);
 }
 $read=json_decode((string)$row,true);
 if(!is_array($read))throw new RuntimeException('Einstellungen nicht lesbar.');
 return tpValidateSettings(array_replace(tpDefaults(),$read));
}
