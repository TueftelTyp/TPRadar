<?php
declare(strict_types=1);
/** Preview and apply restricted cleanup. Never delete linked products or stores. */
function tpCleanup(PDO $db,array $settings,bool $apply=false):array {
 $days=$settings['cleanup_days'];
 $stamp=(new DateTimeImmutable('now'))->modify('-'.$days.' days')->format('Y-m-d H:i:s');
 $counts=['prices'=>0,'products'=>0,'stores'=>0,'pending_to_reject'=>0,'audit'=>0];
 // Mark old pending as rejected first, but only during an explicit cleanup run.
 $pendingCut=(new DateTimeImmutable('today'))->modify('-'.$settings['pending_expire_days'].' days')->format('Y-m-d');
 $stmt=$db->prepare("SELECT COUNT(*) FROM prices WHERE status='pending' AND observed_on<?");$stmt->execute([$pendingCut]);$counts['pending_to_reject']=(int)$stmt->fetchColumn();
 if($apply){
  $stmt=$db->prepare("SELECT id FROM prices WHERE status='pending' AND observed_on<? FOR UPDATE");$stmt->execute([$pendingCut]);$ids=$stmt->fetchAll(PDO::FETCH_COLUMN);
  foreach($ids as $id){$db->prepare("UPDATE prices SET status='rejected',reason='Frist für Bestätigung abgelaufen' WHERE id=?")->execute([$id]);$db->prepare("INSERT IGNORE INTO cleanup_candidates(entity_type,entity_id) VALUES('prices',?)")->execute([$id]);}
 }
 foreach(['prices','products','stores'] as $type){
  $allowed=$type==='prices'?$settings['cleanup_rejected']:$settings['cleanup_inactive'];
  if(!$allowed)continue;
  $join=$type==='prices'?"JOIN prices t ON t.id=c.entity_id AND t.status='rejected'":($type==='products'?"JOIN products t ON t.id=c.entity_id AND t.is_active=0":"JOIN stores t ON t.id=c.entity_id AND t.is_active=0");
  $unlinked=$type==='products'?' AND NOT EXISTS (SELECT 1 FROM prices p WHERE p.product_id=t.id)':($type==='stores'?' AND NOT EXISTS (SELECT 1 FROM prices p WHERE p.store_id=t.id)':'');
  $select="SELECT c.entity_id FROM cleanup_candidates c $join WHERE c.entity_type=? AND c.marked_at<? $unlinked";
  $stmt=$db->prepare($select);$stmt->execute([$type,$stamp]);$ids=$stmt->fetchAll(PDO::FETCH_COLUMN);
  $counts[$type]=count($ids);
  if(!$apply)continue;
  foreach($ids as $id){
   if($type==='prices')$db->prepare('DELETE FROM confirmations WHERE price_id=?')->execute([$id]);
   $condition=$type==='prices'?"status='rejected'":"is_active=0";
   $deleted=$db->prepare("DELETE FROM $type WHERE id=? AND $condition");
   $deleted->execute([$id]);
   if($deleted->rowCount()!==1)continue;
   $db->prepare('DELETE FROM cleanup_candidates WHERE entity_type=? AND entity_id=?')->execute([$type,$id]);
  }
 }
 $auditStamp=(new DateTimeImmutable('now'))->modify('-'.$settings['audit_retention_days'].' days')->format('Y-m-d H:i:s');
 $st=$db->prepare('SELECT COUNT(*) FROM admin_audit_log WHERE created_at<?');$st->execute([$auditStamp]);$counts['audit']=(int)$st->fetchColumn();
 if($apply)$db->prepare('DELETE FROM admin_audit_log WHERE created_at<?')->execute([$auditStamp]);
 return $counts;
}
