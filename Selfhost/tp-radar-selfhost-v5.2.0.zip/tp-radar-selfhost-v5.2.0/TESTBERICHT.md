# TP-Radar V5.2 – Prüfbericht

## Umfang

Geprüft wurden die PHP-/JavaScript-Dateien, das neue Settings-Modul, die Admin-Einstellungsoberfläche, die Admin-API, die nicht-destruktive SQL-Migration, die Abfrage und Darstellung aktueller Preise sowie die Bereinigungsregeln.

## Automatisierte Prüfungen

- PHP-Syntaxprüfung aller PHP-Dateien mit `php -l`
- JavaScript-Syntaxprüfung aller JS-Dateien mit `node --check`
- `node tests/test_finder.js`: 8 Such-/Barcode-/Geschäfts- und Gültigkeitsprüfungen
- `php tests/test_totp.php`: TOTP-/Base32-Abgleich
- `php -d zend.assertions=1 -d assert.exception=1 tests/test_settings.php`: gültige Defaults, 9 ungültige Settings-Kombinationen, benutzerdefinierte Einstellungen
- `php tests/test_ean.php`: 8 gültige/ungültige GTIN-/EAN-Fälle
- `python tests/test_static.py`: 21 statische Struktur- und Sicherheitsprüfungen
- Archiv-Integrität und Ausschluss aktiver privater Zugangsdaten geprüft

## Maßnahmen zur Datenintegrität

- Die Datei `migrate-5.2.sql` enthält nur `CREATE TABLE IF NOT EXISTS` und `INSERT IGNORE` für ergänzende Verwaltungstabellen/Markierungen. Keine Löschung oder Änderung bestehender Preis-, Produkt- oder Geschäftsdaten.
- Aktive private Konfigurationen sind nicht Bestandteil des Pakets.
- Preisstatus historischer Meldungen bleiben bei Einstellungsänderungen unverändert. Adminfreigaben erfolgen weiter über die bestehende Produkt-/Geschäftsverwaltung.
- Die Bereinigung ist standardmäßig deaktiviert. Eine automatische Ausführung erfolgt ausschließlich über einen optionalen privaten PHP-CLI-Cronjob, sofern der Admin sie zuvor aktiviert hat.
- Neue Deaktivierungen/Ablehnungen werden ab dem jeweiligen Ereignis vorgemerkt; bestehende abgelehnte/deaktivierte Datensätze frühestens ab Installation der Migration.
- Produkte/Geschäfte mit Preisreferenzen werden bei der Bereinigung nicht endgültig gelöscht. Bestätigungen zu zu löschenden abgelehnten Preisen werden vorher entfernt.

## Grenzen

In der Testumgebung steht **kein PDO-MySQL-/MariaDB-Server** zur Verfügung. Deshalb wurde weder eine echte MySQL-Migration noch die vollständige Ende-zu-Ende-Abwicklung (Admin-Login/TOTP, Preis melden, Bestätigungen, Cron-Bereinigung auf produktiver DB) auf einem Live-Webspace ausgeführt. Gleiches gilt für kamerabasierte Barcode-Erkennung auf realen Mobilgeräten. Diese Prüfungen müssen vor öffentlicher Freigabe auf einer Testinstallation durchgeführt werden. Die Testläufe belegen keine absolute Fehlerfreiheit und ersetzen kein unabhängiges Sicherheits-Audit.
