'use strict';
const el=id=>document.getElementById(id);let csrf='',state={products:[],prices:[],stores:[],audit:[]},tab='products',editing=null,currentSettings=null;
const html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function notice(message){el('toast').textContent=message;el('toast').hidden=false;}
async function api(action,body=null){let opts={method:'POST',headers:{'Content-Type':'application/json'}};if(body!==null)opts.body=JSON.stringify({...body,csrf});else if(action==='status')opts={method:'GET'};const response=await fetch('api.php?action='+encodeURIComponent(action),opts);let data;try{data=await response.json();}catch{throw Error('Serverantwort unlesbar.');}if(!response.ok||!data.ok)throw Error(data.error||'Unbekannter Fehler');return data;}
function showLogin(){el('login').hidden=false;el('dashboard').hidden=true;}
function showDash(){el('login').hidden=true;el('dashboard').hidden=false;load();}
async function load(){try{const data=await api('list',{});state=data;render();}catch(e){notice(e.message);if(/Sitzung/.test(e.message))showLogin();}}
function number(n){return Number(n).toLocaleString('de-DE');}
function render(){if(tab==='settings')return;const q=el('search').value.toLowerCase().trim();let arr=state[tab]||[];arr=arr.filter(x=>JSON.stringify(x).toLowerCase().includes(q));let heads=[],rows='';
 if(tab==='products') {heads=['ID','Produkt','Eigenschaften','Status','Aktion'];rows=arr.map(x=>`<tr><td>${x.id}</td><td><strong>${html(x.name)}</strong><small>${html(x.ean||'ohne EAN')}</small></td><td>${x.rolls} Rollen · ${x.sheets} Blatt · ${x.layers} Lagen</td><td>${Number(x.is_active)?'Aktiv':'Deaktiviert'}</td><td><button data-edit="products" data-id="${x.id}">Bearbeiten</button></td></tr>`).join('');}
 if(tab==='prices') {heads=['ID','Produkt','Geschäft','Preis/Datum','Status','Aktion'];rows=arr.map(x=>`<tr><td>${x.id}</td><td>${html(x.product_name)}</td><td>${html(x.store_name)}</td><td>${(x.price_cents/100).toFixed(2).replace('.',',')} €<small>${html(x.observed_on)}</small></td><td class="${x.status==='pending'?'bad':''}">${html(x.status)}</td><td><button data-edit="prices" data-id="${x.id}">Prüfen</button></td></tr>`).join('');}
 if(tab==='stores') {heads=['ID','Geschäft','Status','Aktion'];rows=arr.map(x=>`<tr><td>${x.id}</td><td>${html(x.name)}</td><td>${Number(x.is_active)?'Aktiv':'Deaktiviert'}</td><td><button data-edit="stores" data-id="${x.id}">Bearbeiten</button></td></tr>`).join('');}
 if(tab==='audit') {heads=['Zeit','Aktion','Bereich','ID'];rows=arr.map(x=>`<tr><td>${html(x.created_at)}</td><td>${html(x.action)}</td><td>${html(x.entity_type)}</td><td>${x.entity_id}</td></tr>`).join('');}
 el('createStore').hidden=(tab!=='stores');
 el('tableWrap').innerHTML=`<table><thead><tr>${heads.map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${rows||`<tr><td colspan="${heads.length}">Keine Einträge gefunden.</td></tr>`}</tbody></table>`;
 el('tableWrap').querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>edit(b.dataset.edit,Number(b.dataset.id))));
}
function field(key,label,value,type='text',extra=''){return `<label>${html(label)}<input name="${html(key)}" type="${type}" value="${html(value??'')}" ${extra}></label>`;}
function edit(type,id){const item=state[type].find(x=>Number(x.id)===id);if(!item)return;editing={type,id};el('dialogTitle').textContent=type==='products'?'Produkt bearbeiten':type==='stores'?'Geschäft bearbeiten':'Preis prüfen/bearbeiten';let fields='';
 if(type==='products')fields=field('name','Name',item.name,'text','required maxlength="120"')+field('ean','EAN (optional)',item.ean||'','text','pattern="[0-9]{8,14}"')+field('rolls','Rollen',item.rolls,'number','required min="1" max="500"')+field('sheets','Blätter pro Rolle',item.sheets,'number','required min="1" max="2000"')+field('layers','Lagen',item.layers,'number','required min="1" max="10"')+`<label class="inline"><input type="checkbox" name="is_active" ${Number(item.is_active)?'checked':''}> Aktiv (sonst aus öffentlicher Ansicht ausblenden)</label><p>Änderungen an Rollen, Blättern oder Lagen verändern die berechneten Preise aller historischen Angebote dieses Produkts.</p>`;
 if(type==='stores')fields=field('name','Geschäft',item.name,'text','required maxlength="80"')+`<label class="inline"><input type="checkbox" name="is_active" ${Number(item.is_active)?'checked':''}> Aktiv</label>`+`<label>Mit anderem Geschäft zusammenführen (optional)<select name="target_id"><option value="">Nicht zusammenführen</option>${state.stores.filter(s=>Number(s.id)!==id).map(s=>`<option value="${s.id}">${html(s.name)} (#${s.id})</option>`).join('')}</select></label><label class="inline"><input type="checkbox" name="confirm_merge"> Zusammenführung ausdrücklich bestätigen (nur bei Zielauswahl)</label>`;
 if(type==='prices')fields=`<p>${html(item.product_name)} · ${html(item.store_name)}</p>`+field('price_cents','Preis in Cent',item.price_cents,'number','required min="1" max="999999"')+field('observed_on','Beobachtet am',item.observed_on,'date','required')+`<label>Prüfstatus<select name="status"><option value="confirmed" ${item.status==='confirmed'?'selected':''}>Bestätigt</option><option value="pending" ${item.status==='pending'?'selected':''}>Ausstehend</option><option value="rejected" ${item.status==='rejected'?'selected':''}>Abgelehnt / deaktiviert</option></select></label><label class="inline"><input type="checkbox" name="confirm_reject"> Ablehnung ausdrücklich bestätigen (bei Status „Abgelehnt“)</label>`;
 el('editFields').innerHTML=fields;el('editor').showModal();}
async function submitEdit(ev){ev.preventDefault();const submit=el('editForm').querySelector('button[type=submit]');if(submit.disabled)return;submit.disabled=true;try{
 if(!editing){
  const f=new FormData(el('editForm'));
  const name=String(f.get('name')||'').trim();
  if(!name){notice('Bitte einen Geschäftsnamen eingeben.');return;}
  await api('create_store',{name});
  el('editor').close();notice('Geschäft angelegt.');await load();return;
 }
 const f=new FormData(el('editForm'));const data=Object.fromEntries(f.entries());data.type=editing.type;data.id=editing.id;if(editing.type!=='prices')data.is_active=f.has('is_active');
 if(editing.type==='stores'&&data.target_id){if(!f.has('confirm_merge')){notice('Bitte die Zusammenführung im Formular ausdrücklich bestätigen.');return;}await api('merge_store',{id:editing.id,target_id:Number(data.target_id)});}else{if(editing.type==='prices'&&data.status==='rejected'&&!f.has('confirm_reject')){notice('Bitte das Ablehnen im Formular bestätigen.');return;}await api('save',data);}
 el('editor').close();notice('Änderung gespeichert.');await load();}finally{submit.disabled=false;}}
el('createStore').addEventListener('click',()=>{
 editing=null;el('dialogTitle').textContent='Neues Geschäft anlegen';
 el('editFields').innerHTML=field('name','Geschäftsname','','text','required maxlength="80" autocomplete="off"');
 el('editor').showModal();
 const nameField=el('editForm').elements.namedItem('name');if(nameField)nameField.focus();
});
el('loginForm').addEventListener('submit',async e=>{e.preventDefault();const submit=el('loginForm').querySelector('button[type=submit]');if(submit.disabled)return;submit.disabled=true;try{if(!csrf){const pre=await api('status');csrf=pre.csrf||'';}const data=await api('login',{username:el('username').value,password:el('password').value,totp:el('totp').value});csrf=data.csrf;el('password').value='';el('totp').value='';showDash();}catch(e){notice(e.message);}finally{submit.disabled=false;}});
el('editForm').addEventListener('submit',e=>{submitEdit(e).catch(err=>notice(err.message));});
el('close').onclick=()=>el('editor').close();el('cancel').onclick=()=>el('editor').close();el('reload').onclick=load;el('search').oninput=render;
el('logout').onclick=async()=>{try{await api('logout',{});csrf='';showLogin();}catch(e){notice(e.message);}};
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{
 tab=b.dataset.tab;document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x===b));
 el('dataPanel').hidden=tab==='settings';el('settingsPanel').hidden=tab!=='settings';
 el('search').value='';if(tab==='settings')loadSettings().catch(e=>notice(e.message));else render();
});
api('status').then(d=>{csrf=d.csrf||'';if(d.authenticated){showDash();}else showLogin();}).catch(e=>{showLogin();notice(e.message);});

const settingSections=[
 ['Community & Prüfung',[
 ['first_price_review','Erste Preisangaben prüfen','bool','Neue Erstpreise benötigen Bestätigungen.'],
 ['deviation_review','Preisabweichungen prüfen','bool','Auffällige Preise zurückhalten und Rückfrage anzeigen.'],
 ['ean_required','EAN bei neuen Produkten verpflichtend','bool','EAN-8, EAN-12, EAN-13 und EAN-14 mit gültiger Prüfziffer.'],
 ['warning_percent','Warnung bei Preisabweichung (%)','number','Abweichung vom zuletzt bestätigten Preis.'],
 ['hold_percent','Zurückhalten ab Preisabweichung (%)','number','Muss größer als die Warnschwelle sein.'],
 ['confirmations_required','Unabhängige Bestätigungen','number','1–5 unterschiedliche Browserkennungen.']]],
 ['Gültigkeit & Meldelimits',[
 ['valid_days','Aktuelle Preise (Tage)','number','Ältere Preise sind standardmäßig nicht im Ranking.'],
 ['pending_expire_days','Ausstehende Meldungen nach (Tagen) ablehnen','number','Wird beim Bereinigungslauf angewendet.'],
 ['max_price_reports_day','Preismeldungen je IP / 24 Stunden','number','Zusätzlich bleiben allgemeine Schreiblimits aktiv.'],
 ['max_new_products_day','Neue Produkte je IP / 24 Stunden','number','Nur echte Neuanlagen werden gezählt.'],
 ['max_new_stores_day','Neue Geschäfte je IP / 24 Stunden','number','Nur echte Neuanlagen werden gezählt.'],
 ['new_products_require_approval','Neue Produkte brauchen Adminfreigabe','bool','Neue Produkte sind zunächst ausgeblendet; zugehörige Preise warten.'],
 ['new_stores_require_approval','Neue Geschäfte brauchen Adminfreigabe','bool','Neue Geschäfte sind zunächst ausgeblendet; zugehörige Preise warten.']]],
 ['Öffentliche Darstellung',[
 ['ranking_default','Standard-Ranking','select','Preis pro Blatt, Lagenblatt oder Rolle.'],
 ['home_search_default','Schnellsuche als Startansicht','bool','Auf Smartphones zuerst die Suche zeigen.'],
 ['show_expired','Abgelaufene Preise zusätzlich anzeigen','bool','Deutlich als abgelaufen kennzeichnen.'],
 ['show_pending','Ausstehende Preisprüfungen anzeigen','bool','Nur separat, niemals als verlässlichen Sieger.'],
 ['prefer_store_filter','Geschäftsfilter bevorzugen','bool','Lokal gespeichertes Geschäft vorbelegen.']]],
 ['Aufbewahrung & Bereinigung',[
 ['auto_cleanup','Bereinigung erlauben','bool','Schaltet manuelle und optionale Cron-Bereinigung frei.'],
 ['cleanup_days','Löschfrist ab Ablehnung/Deaktivierung (Tage)','number','Mindestens 7 Tage. Alte Einträge werden nicht rückwirkend markiert.'],
 ['cleanup_rejected','Abgelehnte Preise bereinigen','bool','Erst nach Ablauf der markierten Frist.'],
 ['cleanup_inactive','Deaktivierte Einträge bereinigen','bool','Nur Produkte und Geschäfte ohne Preisreferenzen.'],
 ['audit_retention_days','Admin-Protokoll aufbewahren (Tage)','number','Protokolle werden erst beim Bereinigungslauf gekürzt.']]]
];
function settingControl(key,label,type,desc,value){
 const id='setting-'+key;const explanation=`<small class="hint">${html(desc)}</small>`;
 if(type==='bool')return `<label class="setting-check"><input id="${id}" type="checkbox" ${value?'checked':''}><span><strong>${html(label)}</strong>${explanation}</span></label>`;
 if(type==='select')return `<label class="setting-field"><strong>${html(label)}</strong><select id="${id}"><option value="sheet" ${value==='sheet'?'selected':''}>Preis / Blatt</option><option value="layer_sheet" ${value==='layer_sheet'?'selected':''}>Preis / Lagenblatt</option><option value="roll" ${value==='roll'?'selected':''}>Preis / Rolle</option></select>${explanation}</label>`;
 return `<label class="setting-field"><strong>${html(label)}</strong><input id="${id}" type="number" min="1" step="1" required value="${Number(value)}">${explanation}</label>`;
}
async function loadSettings(){const d=await api('settings_get',{});currentSettings=d.settings;
 el('settingsFields').innerHTML=settingSections.map(([title,fields])=>`<fieldset><legend>${html(title)}</legend><div class="settings-group">${fields.map(([key,label,type,desc])=>settingControl(key,label,type,desc,currentSettings[key])).join('')}</div></fieldset>`).join('');
}
el('settingsForm').addEventListener('submit',async e=>{e.preventDefault();const submit=e.currentTarget.querySelector('[type=submit]');if(submit.disabled)return;submit.disabled=true;
 try{const next={};for(const [,fields] of settingSections)for(const [key,,type] of fields){const control=el('setting-'+key);next[key]=type==='bool'?control.checked:type==='number'?Number(control.value):control.value;}
 const result=await api('settings_save',{settings:next});currentSettings=result.settings;notice('Einstellungen gespeichert. Neue Preisregeln sind sofort aktiv.');}
 catch(err){notice(err.message);}finally{submit.disabled=false;}
});
el('cleanupPreview').addEventListener('click',async()=>{const b=el('cleanupPreview');b.disabled=true;try{const d=await api('cleanup_preview',{});el('cleanupResult').textContent=JSON.stringify(d.counts,null,2);}catch(e){notice(e.message);}finally{b.disabled=false;}});
el('cleanupNow').addEventListener('click',async()=>{if(!currentSettings?.auto_cleanup){notice('Bitte zuerst die Bereinigung aktivieren und speichern.');return;}
 const ok=await new Promise(resolve=>{const dialog=el('cleanupDialog');const yes=el('cleanupConfirm');const no=el('cleanupCancel');const finish=v=>{dialog.close();yes.onclick=null;no.onclick=null;resolve(v);};yes.onclick=()=>finish(true);no.onclick=()=>finish(false);dialog.oncancel=e=>{e.preventDefault();finish(false)};dialog.showModal();});if(!ok)return;
 const b=el('cleanupNow');b.disabled=true;try{const d=await api('cleanup_run',{confirm_cleanup:true});el('cleanupResult').textContent=JSON.stringify(d.counts,null,2);notice('Bereinigung durchgeführt.');await load();}catch(e){notice(e.message);}finally{b.disabled=false;}
});
