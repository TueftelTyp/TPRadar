<?php
declare(strict_types=1);
$source=file_get_contents(dirname(__DIR__).'/public/api.php');
if(!preg_match('/function tpValidEAN\(.*?(?=function throttleNew\()/s',$source,$matches))throw new RuntimeException('EAN function missing');
eval($matches[0]);
$good=['4006381333931','96385074','012345678905'];
$bad=['4006381333932','96385075','abcdefgh','123456789',''];
foreach($good as $ean){if(!tpValidEAN($ean)){fwrite(STDERR,"Valid EAN rejected: $ean\n");exit(1);}}
foreach($bad as $ean){if(tpValidEAN($ean)){fwrite(STDERR,"Invalid EAN accepted: $ean\n");exit(1);}}
echo "OK: GTIN/EAN Prüfziffer und Format (8 Fälle)\n";
