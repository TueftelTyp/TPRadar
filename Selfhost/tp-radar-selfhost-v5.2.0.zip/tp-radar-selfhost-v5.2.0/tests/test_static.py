from pathlib import Path
import re, json, struct, sys
p=Path(__file__).resolve().parent.parent
sources={f.relative_to(p).as_posix():f.read_text(encoding='utf-8') for f in p.rglob('*') if f.is_file() and f.suffix in ('.php','.js','.html','.sql','.md','.css','.webmanifest')}
checks={
'Keine feste Benutzer-Domain': not any(re.search(r'(?:tpr|tp)\.2ix\.de|USER[0-9]{5,}|db_[0-9]{5,}',x) for x in sources.values()),
'Keine aktive Konfiguration': not any((p/'private'/x).exists() for x in ('config.php','admin.php','setup.php')),
'Admin-Endpunkte geschützt': all(x in sources['public/adm/api.php'] for x in ("function required()", "function csrfCheck(", "function totpStep(","function originCheck()", "session_regenerate_id(true)")),
'Öffentliches PDO prepared': "PDO::ATTR_EMULATE_PREPARES=>false" in sources['public/api.php'],
'Datenbank hat 10 Tabellen': len(re.findall(r'CREATE TABLE\s+\w+',sources['schema.sql']))==10,
'Keine destruktiven SQL-Befehle': not re.search(r'(?im)^\s*(DROP|DELETE|TRUNCATE|ALTER)\b', sources['schema.sql']),
'Definierte Charset-Einstellungen': sources['schema.sql'].count('CHARSET=utf8mb4')==10,
'CSRF und TOTP bei Setup': 'verifyTOTP(' in sources['public/adm/setup.php'] and "$_SESSION['setup_csrf']" in sources['public/adm/setup.php'],
'Preisbestätigung geschützt': "hash_equals($item['reporter_hash'],$actor)" in sources['public/api.php'],
'PWA Cache getrennt': 'k.startsWith(PREFIX)' in sources['public/sw.js'],
'API ohne PWA Cache': "pathname.endsWith('/api.php')" in sources['public/sw.js'],
'Admin ohne PWA Cache': "pathname.includes('/adm/')" in sources['public/sw.js'],
'Alle Versionen gleich': all(not re.search(r'5\.0\.[12]',v) for k,v in sources.items() if k not in ('tests/test_static.py','INSTALLATION.md')),
'Installationsdoku vorhanden': '## A. Neue Installation' in sources['INSTALLATION.md'],
'Schlüssel nur als Platzhalter': 'CHANGE_TO_A_UNIQUE' in sources['private/config.example.php'],
'Geschäfte öffentlich auswählbar': "'stores'=>$stores" in sources['public/api.php'] and 'state.stores' in sources['public/app.js'],
'UTF-8 API validiert': 'if($normalized===null)' in sources['public/api.php'] and 'if($normalized===null)' in sources['public/adm/api.php'],
'Admin Einstellungen geschützt': 'settings_save' in sources['public/adm/api.php'] and 'required();csrfCheck($data)' in sources['public/adm/api.php'],
'Bereinigung optional': 'auto_cleanup' in sources['private/settings.php'] and 'tpCleanup' in sources['private/cleanup.php'],
'Migration nicht destruktiv': not re.search(r'(?im)^\s*(DROP|DELETE|TRUNCATE|ALTER)\b',sources['migrate-5.2.sql']),
'PWA Manifest valide': json.loads(sources['public/manifest.webmanifest'])['display']=='standalone',
}
for name,ok in checks.items():print(('OK' if ok else 'FAIL')+'  '+name)
if not all(checks.values()):sys.exit(1)
print(f'{len(checks)} statische Prüfungen bestanden')
