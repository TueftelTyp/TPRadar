<?php
declare(strict_types=1);
require dirname(__DIR__).'/private/settings.php';
$base=tpDefaults();
assert(count($base)===23);
assert(tpValidateSettings($base)===$base);
foreach([
 ['warning_percent'=>100], ['hold_percent'=>5,'warning_percent'=>10],
 ['confirmations_required'=>0],['valid_days'=>0],['auto_cleanup'=>'yes'],
 ['ean_required'=>1],['ranking_default'=>'bad'],['cleanup_days'=>0],
 ['unknown_setting'=>true]
] as $values){
 $bad=array_replace($base,$values);$failed=false;
 try{tpValidateSettings($bad);}catch(InvalidArgumentException $e){$failed=true;}
 if(!$failed){fwrite(STDERR,'Invalid settings accepted: '.json_encode($values)."\n");exit(1);}
}
$custom=array_replace($base,['first_price_review'=>true,'ean_required'=>true,'auto_cleanup'=>true,'cleanup_days'=>180]);
if(tpValidateSettings($custom)!==$custom)exit(1);
echo "OK: settings defaults, 9 negative cases, custom case\n";
