-- TP-Radar 5.2: ONLY FOR AN EXISTING V5.1 DATABASE. Back up database first.
-- Does not delete or modify existing product, store or price records.
CREATE TABLE IF NOT EXISTS app_settings (
 id TINYINT UNSIGNED PRIMARY KEY,
 settings_json LONGTEXT NOT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE IF NOT EXISTS cleanup_candidates (
 entity_type ENUM('products','stores','prices') NOT NULL,
 entity_id BIGINT UNSIGNED NOT NULL,
 marked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(entity_type,entity_id),
 INDEX idx_cleanup_marked(marked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Bestandseinträge werden ab dem Zeitpunkt dieser Migration vorgemerkt; kein sofortiges Löschen.
INSERT IGNORE INTO cleanup_candidates(entity_type,entity_id) SELECT 'products',id FROM products WHERE is_active=0;
INSERT IGNORE INTO cleanup_candidates(entity_type,entity_id) SELECT 'stores',id FROM stores WHERE is_active=0;
INSERT IGNORE INTO cleanup_candidates(entity_type,entity_id) SELECT 'prices',id FROM prices WHERE status='rejected';
