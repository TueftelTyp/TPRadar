<?php
declare(strict_types=1);
/** Run via a private cron or CLI only. NEVER place tools/ inside public/. */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit(1); }
$root=dirname(__DIR__);
if (!is_file($root.'/private/config.php')) { fwrite(STDERR,"Konfiguration fehlt.\n"); exit(1); }
require_once $root.'/private/settings.php';
require_once $root.'/private/cleanup.php';
try {
    $cfg=require $root.'/private/config.php';
    $db=new PDO($cfg['dsn'],$cfg['user'],$cfg['password'],[
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
    ]);
    $settings=tpSettings($db);
    if (!$settings['auto_cleanup']) { echo "Automatische Bereinigung deaktiviert.\n"; exit(0); }
    $lock=$db->query("SELECT GET_LOCK('tp_radar_cleanup_v52',0)")->fetchColumn();
    if ((int)$lock!==1) { fwrite(STDERR,"Ein anderer Bereinigungslauf ist aktiv.\n"); exit(1); }
    try {
        $db->beginTransaction();
        $counts=tpCleanup($db,$settings,true);
        $stmt=$db->prepare('INSERT INTO admin_audit_log(action,entity_type,entity_id,before_json,after_json) VALUES(?,?,?,?,?)');
        $stmt->execute(['cleanup_cron','app_settings',1,null,json_encode($counts,JSON_THROW_ON_ERROR)]);
        $db->commit();
        echo json_encode($counts,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)."\n";
    } catch (Throwable $e) {
        if($db->inTransaction())$db->rollBack();
        throw $e;
    } finally { $db->query("SELECT RELEASE_LOCK('tp_radar_cleanup_v52')"); }
} catch (Throwable $e) {
    error_log('TP-Radar cron: '.$e->getMessage());
    fwrite(STDERR,"Bereinigung fehlgeschlagen (Details im PHP-Log).\n");
    exit(1);
}
