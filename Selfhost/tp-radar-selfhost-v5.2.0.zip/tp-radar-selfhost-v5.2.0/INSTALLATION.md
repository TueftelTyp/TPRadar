# TP-Radar V5.2 – Installation und Upgrade

## Voraussetzungen

- PHP 8.1+ mit `pdo_mysql`, `mbstring`, JSON, Session-Unterstützung und TLS/HTTPS
- MySQL oder MariaDB mit InnoDB und utf8mb4
- HTTPS-Domain/Subdomain, deren Document Root **nur** `public/` ist; keine Installation im Unterverzeichnis (`/adm`-Cookie-Pfad)
- Schreib-/Leserechte des PHP-Datenbankbenutzers; für einmalige SQL-Importe zusätzlich CREATE-Rechte
- Authenticator-App zur einmaligen Admin-Einrichtung

## A. Neue Installation

1. Neue **leere** MySQL-Datenbank erstellen und in phpMyAdmin auswählen.
2. **Nur `schema.sql`** importieren; es erstellt 10 Tabellen ohne DROP-Befehle. Nicht über vorhandene Tabellen importieren.
3. Das gesamte Paket hochladen; `private/` muss neben `public/` und außerhalb des öffentlich erreichbaren Ordners liegen.
4. `private/config.example.php` als `private/config.php` kopieren und DSN (Datenbankname/Host), Datenbankbenutzer, Passwort, einen eigenen zufälligen `secret` (mind. 32 Zeichen) und `site_origin` (`https://DEINE-DOMAIN`, ohne Slash/Pfad) eintragen. Niemals Zugangsdaten ins öffentliche Verzeichnis kopieren.
5. `private/setup.example.php` als `private/setup.php` kopieren, darin `site_origin` setzen und einen zufälligen `setup_key` (mind. 32 Zeichen) aus dem Passwortmanager eintragen.
6. `/adm/setup.php` im Browser öffnen; mit Einrichtungsschlüssel, Benutzername, neuem Admin-Passwort und TOTP-App einrichten. Danach `private/setup.php` löschen und den TOTP-Schlüssel sicher aufbewahren.
7. `/adm/` öffnen, einloggen, unter **Einstellungen** Regeln nach Bedarf anpassen.

## B. Update von V5.1.0 auf V5.2.0 ohne Datenverlust

1. **Vollständiges SQL-Backup** erstellen und die bestehenden Webdateien sichern.
2. In phpMyAdmin genau die bisherige Datenbank auswählen und **nur `migrate-5.2.sql`** importieren. Das Skript legt `app_settings` und `cleanup_candidates` an. Produkte, Preise, Geschäfte und bestehende Admin-Daten werden weder gelöscht noch zurückgesetzt. Bereits abgelehnte/deaktivierte Datensätze erhalten eine vorgemerkte Frist ab Migration; sie werden dabei nicht gelöscht. Die Migration darf bei Bedarf erneut ausgeführt werden.
3. Projektdateien hochladen; dabei folgende aktive Dateien **nicht überschreiben**: `private/config.php`, `private/admin.php`, `private/setup.php`, `private/moderation.php` (falls angepasst). Die neuen Dateien `private/settings.php`, `private/cleanup.php`, `public/adm/*`, `public/api.php`, `public/app.js`, `public/index.html`, `public/sw.js` und übrige öffentliche Dateien aktualisieren. Bestehende MySQL-Daten nicht importieren oder zurücksetzen.
4. `/adm/version.php` muss **5.2.0** anzeigen. Bei alten Dateien Browser/PWA schließen und neu laden, Service-Worker-Cache aktualisieren.
5. `/adm/` anmelden und unter **Einstellungen** die bisherige Preisprüfung kontrollieren. Solange noch keine neuen Einstellungen gespeichert wurden, werden existierende Werte aus `private/moderation.php` übernommen. Erst beim Speichern übernimmt die Datenbank diese Werte.
6. Nach erfolgreichem Upgrade MySQL-Rechte für den PHP-Benutzer wieder auf SELECT, INSERT, UPDATE, DELETE ohne Schemaänderung begrenzen.

**Achtung:** `schema.sql` ist ausschließlich für eine komplett neue Datenbank. Die bestehende Datenbank **nicht** leeren oder neu anlegen.

## C. Einstellungen und Verhalten

Unter `/adm/` → **Einstellungen** gibt es:

- **Community-Prüfung bei Erstpreisen** separat von **Community-Prüfung bei Preisabweichung**; die normalen Defaults sind Erstpreis aus, Abweichungen an.
- **EAN-Pflicht** für neue Produkte; bestehende Produkte ohne EAN bleiben gültig. Wenn angegeben, wird die GTIN-Prüfziffer überprüft. Die eindeutige EAN-Zuordnung ist immer aktiv.
- **Warnung** (10 %), **Zurückhalten** (30 %) und **unabhängige Bestätigungen** (2). Selbstbestätigungen bleiben verboten. Änderungen greifen nur für neue Meldungen bzw. weitere Bestätigungen; bestehende Status werden nicht rückwirkend geändert.
- Preisgültigkeit (30 Tage), Verfallszeit für ausstehende Meldungen (30 Tage), tägliche Melde- und Neuanlagelimits, Adminfreigabe neuer Produkte/Geschäfte.
- Standard-Ranking, Startansicht mit Schnellsuche, Geschäftsauswahl merken, Anzeige abgelaufener und ausstehender Preise. Abgelaufene Preise werden gekennzeichnet und nach aktuellen Angeboten angezeigt, zählen jedoch nicht als aktuelle Sieger. Ausstehende Preise werden niemals als bestätigte Sieger gerankt.
- **Bereinigung standardmäßig aus.** Bei Aktivierung: Zeitspanne (90 Tage), getrennte Auswahl für abgelehnte Preise und deaktivierte Produkte/Geschäfte, Protokoll-Aufbewahrung (365 Tage). Die Vorschau zeigt geplante Aktionen; erst „Jetzt bereinigen“ mit zusätzlicher Bestätigung führt Löschungen aus.

Die Löschfrist beginnt mit **Ablehnung/Deaktivierung**, nicht mit dem Erstellungsdatum. Für bereits betroffene Einträge beginnt sie frühestens mit dem V5.2-Migrationszeitpunkt. Produkte und Geschäfte werden niemals gelöscht, solange Preisreferenzen bestehen. Veraltete ausstehende Preise werden bei der Bereinigung zunächst abgelehnt und vorgemerkt; sie werden **nicht sofort** endgültig entfernt.

## D. Optionale automatische Bereinigung (Cron)

Automatische Löschungen erfolgen **nicht** bei normalen Seitenaufrufen. Aktiviere zunächst in der Adminoberfläche die Bereinigung. Wenn dein Hoster einen privaten PHP-CLI-Cronjob unterstützt, kann er anschließend beispielsweise einmal täglich laufen:

```sh
/usr/bin/php /ABSOLUTER/PFAD/ZUM/PROJEKT/tools/cleanup.php
```

Das Skript ist **nur für PHP-CLI** zugelassen; `tools/` darf nicht im Webroot liegen. Der CLI-PHP-Prozess benötigt Zugriff auf die private Konfiguration und MySQL. Bei fehlendem Cronjob steht die manuelle Bereinigung in `/adm/` zur Verfügung. Bitte auf Shared Hosting die PHP-CLI-Pfade prüfen. Adminaktionen werden im Audit-Log erfasst (bis zur eingestellten Aufbewahrungsfrist).

## E. Sicherheitsprüfung nach Installation

- `https://DEINE-DOMAIN/` lädt und die API `/api.php?action=list` liefert `ok: true`.
- `/adm/version.php` zeigt 5.2.0, Anmeldung mit Passwort und TOTP funktioniert.
- `private/config.php`, `private/admin.php`, `private/setup.php` und `tools/cleanup.php` sind **per URL nicht erreichbar**.
- Unter Einstellungen Änderungen speichern, neu laden und Werte überprüfen.
- Community-Erstpreis-/Abweichungsprüfung anhand kleiner, nachvollziehbarer Testpreise prüfen.
- Bereinigungsvorschau zuerst nur lesen; vor produktiven Löschungen Backup erstellen.
- PWA aktualisieren und auf Smartphone Suche, Filter, Barcode und Dark Mode testen.

## Testgrenzen

Im Release enthalten sind statische Prüfungen, JS-Suchtests, PHP-TOTP-Tests und Einstellungsvalidierung. Ein echter MySQL-/MariaDB-Integrationstest und ein Browser-/Kameratest auf allen Hosting-Varianten sind nicht Teil des Pakets. Systemzeit und Berechtigungen müssen auf dem Zielhost geprüft werden.
