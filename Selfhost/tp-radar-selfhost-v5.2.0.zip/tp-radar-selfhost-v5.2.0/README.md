# TP-Radar 5.2 – Community-Preisvergleich für Toilettenpapier

TP-Radar ist eine deutschsprachige, selbst hostbare Web-App für den Preisvergleich von Toilettenpapier im Geschäft. Produkte lassen sich per Name oder EAN finden; auf unterstützten Smartphones kann die Kamera Barcodes scannen. Eine Geschäftsnamenssuche filtert Angebote ohne Standortfreigabe. Verglichen werden Packungspreis, Preis pro Rolle, Preis pro Blatt und Preis pro Lagenblatt.

## Funktionen

- Mobile Oberfläche, Dark Mode, installierbare PWA und Preisverläufe
- Anonyme Community-Meldungen und unabhängige Bestätigungen ohne Kundenkonten
- Administrationsbereich unter `/adm/` mit Passwort **und** TOTP
- Produkt-, Geschäfts- und Preisverwaltung mit Änderungsprotokoll
- **Neue Einstellungen unter `/adm/ → Einstellungen`:** Erstpreis- und Abweichungsprüfung separat, EAN-Pflicht, Schwellenwerte, Bestätigungen, Gültigkeit, Meldelimits, Freigaben, Standard-Ranking sowie Aufbewahrung
- Bereinigungsvorschau; endgültiges Löschen nur nach expliziter Freigabe bzw. über optionalen CLI-Cronjob

## Technologie

HTML/CSS/JavaScript ohne Frontend-Framework, PHP 8.1+ mit PDO und MySQL/MariaDB. Hosting benötigt HTTPS und eine Domain mit Document Root auf `public/`.

## Installation und Aktualisierung

Die vollständige Anleitung steht in **[INSTALLATION.md](INSTALLATION.md)**. Für eine neue Datenbank `schema.sql` verwenden. Eine **bestehende V5.1-Installation** benötigt stattdessen ausschließlich `migrate-5.2.sql` nach einem Backup; niemals das vollständige Schema erneut importieren. Bestehende `private/config.php`, `private/admin.php`, `private/setup.php` und private Schlüssel beim Upload nicht überschreiben.

Alle Beispielkonfigurationen enthalten nur Platzhalter. Das Paket enthält weder fremde Zugänge noch Preisdaten.

## Hinweise

Preisangaben stammen von Nutzern und sind nicht garantiert aktuell oder filialgenau. Geschäftsnamen beziehen sich bislang auf Ketten, nicht einzelne Filialen. Anonyme Gerätekennungen beweisen keine unterschiedlichen Personen. Eine abgeschlossene Sicherheits-/MySQL-End-to-End-Zertifizierung für beliebige Hosting-Umgebungen besteht nicht.
