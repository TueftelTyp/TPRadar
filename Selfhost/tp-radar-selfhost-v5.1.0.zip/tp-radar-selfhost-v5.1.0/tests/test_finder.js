'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const src=fs.readFileSync(__dirname+'/../public/app.js','utf8');
function functionSource(name){let begin=src.indexOf('function '+name+'(');if(begin<0)throw Error('Missing function: '+name);let open=src.indexOf('{',begin),level=0,inStr=null,escape=false,template=false;for(let i=open;i<src.length;i++){let ch=src[i];if(inStr){if(escape){escape=false;continue}if(ch==='\\'){escape=true;continue}if(ch===inStr){inStr=null;continue}continue}if(ch==='\''||ch==='"'||ch==='`'){inStr=ch;continue}if(ch==='{')level++;if(ch==='}'&&--level===0)return src.slice(begin,i+1)}throw Error('Unbalanced '+name)}
const dom={'#finder-store':{value:''},'#finder-product':{value:''}};
const state={products:[{id:1,name:'Extra Soft 3 lagig',ean:'4001234567890',rolls:8,sheets:150,layers:3},{id:2,name:'Basis Papier',ean:'4001234567891',rolls:10,sheets:100,layers:2}],prices:[{id:1,productId:1,store:'Lidl',date:'2026-11-01',price:4.8},{id:2,productId:1,store:'Rewe',date:'2026-11-01',price:4.2},{id:3,productId:2,store:'Lidl',date:'2026-11-02',price:4.0},{id:4,productId:1,store:'Lidl',date:'2026-10-01',price:3}]};
const $=selector=>dom[selector];
const code=['normalizedSearch','finderStoreMatches','finderProductMatches','latest'].map(functionSource).join('\n');
// Set the time and minimal dependencies explicitly to avoid browser reliance.
const context={state,$,today:()=> '2026-11-03',dateMs:d=>new Date(d+'T12:00:00Z').getTime(),Map,Set,Number,String,Date};vm.createContext(context);vm.runInContext(code,context);
const {normalizedSearch,finderStoreMatches,finderProductMatches,latest}=context;
assert.equal(normalizedSearch('  EXTRA  '),'extra');
assert.equal(latest().length,3,'Old price excluded; latest per product and store');
dom['#finder-store'].value='LID';assert.equal(finderStoreMatches('Lidl'),true);assert.equal(finderStoreMatches('Rewe'),false);
dom['#finder-product'].value='4001234567890';assert.equal(finderProductMatches(state.products[0]),true);assert.equal(finderProductMatches(state.products[1]),false);
dom['#finder-product'].value='soft';assert.equal(finderProductMatches(state.products[0]),true);
dom['#finder-product'].value='unbekannt';assert.equal(finderProductMatches(state.products[0]),false);
dom['#finder-product'].value='';dom['#finder-store'].value='';assert.equal(latest().length,3);
console.log('OK: 8 Finder-/Barcode-/Geschäft-/Aktualitätstests');
