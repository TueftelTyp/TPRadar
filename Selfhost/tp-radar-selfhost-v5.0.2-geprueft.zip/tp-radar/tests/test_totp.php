<?php
declare(strict_types=1);
// Regression tests using the actual functions from the distributed PHP sources.
function extractFunctions(string $file, string $start, string $end): void {
    $source=file_get_contents(dirname(__DIR__).'/'.$file);
    $a=strpos($source,$start);$b=strpos($source,$end,$a);
    if($a===false || $b===false)throw new RuntimeException('Function segment not found');
    eval(substr($source,$a,$b-$a));
}
extractFunctions('public/adm/setup.php','function b32enc(', 'function actor(');
extractFunctions('public/adm/api.php','function b32(', 'function actor(');
$key='12345678901234567890';
$encoded=b32enc($key);
assert($encoded==='GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
assert(b32dec($encoded)===$key);
assert(b32($encoded)===$key);
assert(verifyTOTP($encoded,'12345')===null);
assert(totpStep($encoded,'12345')===null);
assert(verifyTOTP('INVALID!','123456')===null);
$now=intdiv(time(),30);
$mac=hash_hmac('sha1',pack('N2',0,$now),$key,true);
$pos=ord($mac[19]) & 15;
$val=((ord($mac[$pos])&127)<<24)|(ord($mac[$pos+1])<<16)|(ord($mac[$pos+2])<<8)|ord($mac[$pos+3]);
$code=str_pad((string)($val % 1000000),6,'0',STR_PAD_LEFT);
if(verifyTOTP($encoded,$code)!==$now || totpStep($encoded,$code)!==$now)throw new RuntimeException('TOTP mismatch');
echo "TOTP: Setup- und Admin-Verifikation identisch (inkl. Base32- und Formatchecks).\n";
